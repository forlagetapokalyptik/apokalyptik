
#Installation
Information on how to install the template in Wordpress can be found in the intall.md file.


#How to use

##Creating a Book


**Thumbnails**

Each book is accompanied by a cover thumbnail and a banner. The images to be used should have the following size:

Cover image: 648px height

Banner Thumbnail: 1280x490 px
